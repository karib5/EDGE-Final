import requests

city = input("Enter city: ")
api_key = 'your_api_key'
url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'

response = requests.get(url)
data = response.json()

if response.status_code == 200:
    temp = data['main']['temp']
    description = data['weather'][0]['description']
    print(f"{city}: {temp}°C, {description}")
else:
    print("City not found.")
