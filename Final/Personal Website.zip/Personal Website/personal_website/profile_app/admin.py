from django.contrib import admin
from .models import WorkExperience

admin.site.register(WorkExperience)
