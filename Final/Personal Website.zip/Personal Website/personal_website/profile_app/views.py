from django.shortcuts import render
from .models import WorkExperience

def home(request):
    experiences = WorkExperience.objects.all()
    return render(request, 'profile_app/home.html', {'experiences': experiences})
