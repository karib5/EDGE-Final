class Account:
    def __init__(self, initial):
        self.balance = initial

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Not enough balance.")

    def check_balance(self):
        print("Balance:", self.balance)


class Customer:
    def __init__(self, customer_name, initial):
        self.name = customer_name
        self.account = Account(initial)


class Transaction:
    def deposit_money(self, customer, amount):
        customer.account.deposit(amount)

    def withdraw_money(self, customer, amount):
        customer.account.withdraw(amount)

    def view_balance(self, customer):
        customer.account.check_balance()

customer = Customer("John", 500)
transaction = Transaction()

transaction.view_balance(customer)
transaction.deposit_money(customer, 200)
transaction.view_balance(customer)
transaction.withdraw_money(customer, 100)
transaction.view_balance(customer)
transaction.withdraw_money(customer, 700)
