import tkinter as tk

def convert():
    temp = float(entry.get())
    if var.get() == 1:
        result.set((temp * 9/5) + 32)
        result.set((temp - 32) * 5/9)

root = tk.Tk()
root.title("Temp Converter")

entry = tk.Entry(root)
entry.grid(row=0, column=1)

var = tk.IntVar()
celsius_radio = tk.Radiobutton(root, text="Celsius to Fahrenheit", variable=var, value=1)
fahrenheit_radio = tk.Radiobutton(root, text="Fahrenheit to Celsius", variable=var, value=2)
celsius_radio.grid(row=1, column=0)
fahrenheit_radio.grid(row=2, column=0)

convert_button = tk.Button(root, text="Convert", command=convert)
convert_button.grid(row=3, column=0)

result = tk.StringVar()
result_label = tk.Label(root, textvariable=result)
result_label.grid(row=3, column=1)

root.mainloop()
