import sqlite3

db_file = 'todo.db'

def setup_database():
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS Todo (
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        Task TEXT NOT NULL
    )''')
    conn.commit()
    conn.close()

def show_menu():
    print("\nSimple To-Do List")
    print("1. View Tasks")
    print("2. Add Task")
    print("3. Exit")
    choice = input("Choose an option: ")
    return choice

def view_tasks():
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("SELECT Id, Task FROM Todo")
    tasks = c.fetchall()
    conn.close()

    if tasks:
        print("\nID | Task")
        for task in tasks:
            print(f"{task[0]} | {task[1]}")
    else:
        print("No tasks found.")

def add_task():
    task = input("Enter your task: ")
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("INSERT INTO Todo (Task) VALUES (?)", (task,))
    conn.commit()
    conn.close()
    print("Task added successfully!")

def main():
    setup_database()

    while True:
        choice = show_menu()

        if choice == '1':
            view_tasks()
        elif choice == '2':
            add_task()
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
