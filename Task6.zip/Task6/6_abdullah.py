from collections import Counter

def count_words(filename):
    with open(filename, 'r') as file:
        text = file.read().lower().split()
    word_count = Counter(text)
    top_10 = word_count.most_common(10)
    for word, count in top_10:
        print(word, count)

count_words('sample.txt')
