import re

def find_contacts(filename):
    with open(filename, 'r') as file:
        text = file.read()

    emails = re.findall(r'\S+@\S+', text)
    phones = re.findall(r'\b\d{10}\b', text)

    print("Emails:")
    for email in emails:
        print(email)

    print("\nPhone numbers:")
    for phone in phones:
        print(phone)

# Example usage:
find_contacts('sample.txt')
