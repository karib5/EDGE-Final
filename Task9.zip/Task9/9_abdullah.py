import threading

def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def find_primes(s, e, res):
    for n in range(s, e):
        if is_prime(n):
            res.append(n)

def multi_prime_calc(s, e, t):
    thrs = []
    res = []
    step = (e - s) // t
    for i in range(t):
        st = s + i * step
        en = s + (i + 1) * step if i != t - 1 else e
        thr = threading.Thread(target=find_primes, args=(st, en, res))
        thrs.append(thr)
        thr.start()

    for thr in thrs:
        thr.join()

    return res

if __name__ == "__main__":
    s, e, t = 1, 10000, 4
    primes = multi_prime_calc(s, e, t)
    print(f"Primes: {primes[:20]}...")
