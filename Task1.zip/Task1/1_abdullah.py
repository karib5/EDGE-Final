import csv

def calculate(file_name):
    with open(file_name) as file:
        data = csv.reader(file)
        header = next(data)
        print(f"{'Name':<20}{'Average Score':<15}")
        print("=" * 35)
        for row in data:
            name, scores = row[0], map(float, row[1:])
            avg = sum(scores) / len(row[1:])
            print(f"{name:<20}{avg:<15.2f}")

if __name__ == "__main__":
    file_name = "student.csv"
    calculate(file_name)
