from datetime import datetime

def calculate_time_difference(date1, date2):
    date1 = datetime.strptime(date1, '%Y-%m-%d %H:%M:%S')
    date2 = datetime.strptime(date2, '%Y-%m-%d %H:%M:%S')
    delta = abs(date2 - date1)
    days = delta.days
    hours = delta.seconds // 3600
    minutes = (delta.seconds // 60) % 60
    seconds = delta.seconds % 60
    print(f"{days} days, {hours} hours, {minutes} minutes, {seconds} seconds")

calculate_time_difference('2025-01-01 10:00:00', '2025-01-03 14:30:45')
