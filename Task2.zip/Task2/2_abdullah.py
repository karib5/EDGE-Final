import requests
from bs4 import BeautifulSoup
url = 'https://arobyscollection.com/'
response = requests.get(url)
if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    products = soup.find_all('div', class_='product')

    for product in products:
        title = product.find('h2').text if product.find('h2') else 'No Title'
        price = product.find('span', class_='price').text if product.find('span', class_='price') else 'No Price'

        print(f'Title: {title}')
        print(f'Price: {price}')
        print('-' * 30)
else:
    print(f"Failed to retrieve the website. Status code: {response.status_code}")
